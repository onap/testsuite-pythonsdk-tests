#!/bin/sh
CLOUD_FILE=/etc/network/interfaces.d/50-cloud-init.cfg
echo "" >> $CLOUD_FILE
echo "#second interface" >> $CLOUD_FILE
echo "auto ens4" >> $CLOUD_FILE
echo "iface ens4 inet dhcp" >> $CLOUD_FILE
ifup ens4
