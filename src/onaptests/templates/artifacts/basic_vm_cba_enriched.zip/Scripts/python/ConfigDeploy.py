from org.onap.ccsdk.cds.blueprintsprocessor.functions.netconf.executor import \
        NetconfComponentFunction


class ConfigDeploy(NetconfComponentFunction):

    def process(self, execution_request):
        log.info("Hello world")
        return

    def recover(self, runtime_exception, execution_request):
        log.error("Goodbye world")
        return None
