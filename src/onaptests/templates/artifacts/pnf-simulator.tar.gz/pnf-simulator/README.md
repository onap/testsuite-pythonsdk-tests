PNF Simulator Helm chart used in pnf-macro test
