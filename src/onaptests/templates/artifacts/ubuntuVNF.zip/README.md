# UbuntuVNF CBA

This is a test CBA to use with UbuntuVNF heat template (link coming soon).
