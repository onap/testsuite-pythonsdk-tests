#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# -*- coding: utf-8 -*-

from setuptools import setup

setup(
    setup_requires=['pbr','setuptools'],
    pbr=True
)
